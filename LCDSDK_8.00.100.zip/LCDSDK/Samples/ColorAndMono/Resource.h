//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ColorAndMono.rc
//
#define IDD_COLORANDMONO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_HIGHLIGHT                   129
#define IDR_NEXT                        130
#define IDR_PREVIOUS                    131
#define IDR_BACKGROUND                  132
#define IDR_LOGO_SMALL                  133
#define IDR_SLIDER_BASE                 134
#define IDR_SLIDER_BASE_2               135
#define IDR_SLIDER_HIGHLIGHT            136
#define IDR_SLIDER_HIGHLIGHT_2          137
#define IDR_SLIDER_LEFT                 138
#define IDR_SLIDER_MID                  139
#define IDR_SLIDER_RIGHT                140
#define IDB_LOGO                        141
#define IDI_ICON1                       142
#define IDI_NEXT                        142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
